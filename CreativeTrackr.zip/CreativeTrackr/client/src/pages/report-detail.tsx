import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import {
  Calendar,
  ChevronLeft,
  Clock,
  Download,
  FileText,
  LockIcon,
  ChartPie,
  ListTodo,
  Share2,
  User
} from "lucide-react";
import { Link } from "wouter";
import { format } from "date-fns";
import { Report, Project, Task } from "@shared/schema";

export default function ReportDetail() {
  const [, params] = useRoute("/reports/:id");
  const reportId = parseInt(params?.id || "1");
  
  const [activeTab, setActiveTab] = useState("summary");
  
  const { data: report, isLoading: isLoadingReport } = useQuery({
    queryKey: ["/api/reports", reportId],
    queryFn: async () => {
      const response = await fetch(`/api/reports/${reportId}`);
      if (!response.ok) {
        throw new Error("Failed to fetch report");
      }
      return response.json() as Promise<Report>;
    }
  });
  
  const { data: project, isLoading: isLoadingProject } = useQuery({
    queryKey: ["/api/projects", report?.projectId],
    enabled: !!report?.projectId,
    queryFn: async () => {
      const response = await fetch(`/api/projects/${report?.projectId}`);
      if (!response.ok) {
        throw new Error("Failed to fetch project");
      }
      return response.json() as Promise<Project>;
    }
  });
  
  const { data: tasks, isLoading: isLoadingTasks } = useQuery({
    queryKey: ["/api/tasks", report?.projectId],
    enabled: !!report?.projectId && activeTab === "tasks",
    queryFn: async () => {
      const response = await fetch(`/api/tasks?projectId=${report?.projectId}`);
      if (!response.ok) {
        throw new Error("Failed to fetch tasks");
      }
      return response.json() as Promise<Task[]>;
    }
  });
  
  if (isLoadingReport || (isLoadingProject && !!report?.projectId)) {
    return (
      <div className="container mx-auto py-6">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center mb-2">
            <Skeleton className="h-10 w-20" />
          </div>
          
          <div className="mb-6">
            <Skeleton className="h-10 w-64 mb-2" />
            <Skeleton className="h-5 w-96" />
          </div>
          
          <Card className="mb-6">
            <CardHeader className="pb-2">
              <Skeleton className="h-6 w-40" />
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[1, 2, 3, 4].map((i) => (
                  <div key={i} className="space-y-2">
                    <Skeleton className="h-6 w-24" />
                    <Skeleton className="h-4 w-full" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
          
          <Skeleton className="h-10 w-full mb-6" />
          
          <Card>
            <CardHeader>
              <Skeleton className="h-6 w-32" />
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {[1, 2, 3].map((i) => (
                  <Skeleton key={i} className="h-40 w-full" />
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }
  
  if (!report) {
    return (
      <div className="container mx-auto py-6 text-center">
        <h1 className="text-2xl font-bold mb-2">Report not found</h1>
        <p className="text-muted-foreground mb-6">
          The report you're looking for doesn't exist or has been deleted.
        </p>
        <Link href="/dashboard">
          <Button>
            <ChevronLeft className="mr-2 h-4 w-4" />
            Back to Dashboard
          </Button>
        </Link>
      </div>
    );
  }
  
  // Extract and format report data
  const content = report.content as any;
  const completedTasks = content.completedTasks || 0;
  const inProgressTasks = content.inProgressTasks || 0;
  const pendingTasks = content.pendingTasks || 0;
  const totalTasks = completedTasks + inProgressTasks + pendingTasks;
  const completionPercentage = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
  
  // Format time spent
  const totalTimeSpent = content.totalTimeSpent || 0;
  const hours = Math.floor(totalTimeSpent / 60);
  const minutes = totalTimeSpent % 60;
  
  return (
    <div className="container mx-auto py-6">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center mb-2">
          <Link href="/dashboard">
            <Button variant="ghost" size="sm" className="gap-1">
              <ChevronLeft className="h-4 w-4" />
              Back
            </Button>
          </Link>
        </div>
        
        <div className="flex flex-col md:flex-row justify-between items-start gap-4 mb-6">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-3xl font-bold tracking-tight">{report.title}</h1>
              {report.isPrivate && (
                <Badge variant="secondary" className="flex items-center gap-1">
                  <LockIcon className="h-3 w-3" />
                  Private
                </Badge>
              )}
            </div>
            <p className="text-muted-foreground">
              {project ? project.name : `Project ID: ${report.projectId}`} |{" "}
              {format(new Date(report.startDate), "MMM d, yyyy")} -{" "}
              {format(new Date(report.endDate), "MMM d, yyyy")}
            </p>
          </div>
          
          <div className="flex gap-2">
            <Button variant="outline" className="flex items-center gap-2">
              <Share2 className="h-4 w-4" />
              Share
            </Button>
            <Button variant="outline" className="flex items-center gap-2">
              <Download className="h-4 w-4" />
              Export
            </Button>
          </div>
        </div>
        
        <Card className="mb-6">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Report Overview</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <div className="text-2xl font-bold">{completionPercentage}%</div>
                <Progress value={completionPercentage} className="h-2 mt-1" />
                <p className="text-xs text-muted-foreground mt-1">
                  Task completion
                </p>
              </div>
              
              <div>
                <div className="text-2xl font-bold">{totalTasks}</div>
                <p className="text-xs text-muted-foreground mt-1">
                  Total tasks
                </p>
              </div>
              
              <div>
                <div className="text-2xl font-bold">
                  {hours}h {minutes}m
                </div>
                <p className="text-xs text-muted-foreground mt-1 flex items-center">
                  <Clock className="h-3 w-3 mr-1" />
                  Total time spent
                </p>
              </div>
              
              <div>
                <div className="text-2xl font-bold">
                  {format(new Date(report.createdAt), "MMM d, yyyy")}
                </div>
                <p className="text-xs text-muted-foreground mt-1 flex items-center">
                  <Calendar className="h-3 w-3 mr-1" />
                  Report generated
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="grid grid-cols-3 w-full max-w-md mx-auto">
            <TabsTrigger value="summary">Summary</TabsTrigger>
            <TabsTrigger value="tasks">Tasks</TabsTrigger>
            <TabsTrigger value="contributors">Contributors</TabsTrigger>
          </TabsList>
          
          <TabsContent value="summary">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ChartPie className="h-5 w-5" />
                  Report Summary
                </CardTitle>
                <CardDescription>
                  Overview of project progress during the reporting period
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {report.summary && (
                  <div className="space-y-2">
                    <h3 className="font-medium">Executive Summary</h3>
                    <p className="text-muted-foreground">{report.summary}</p>
                  </div>
                )}
                
                <div className="space-y-4">
                  <h3 className="font-medium">Task Status</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Card>
                      <CardHeader className="py-2">
                        <CardTitle className="text-base font-medium text-green-600">Completed</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-3xl font-bold">{completedTasks}</div>
                        <Progress value={100} className="h-2 mt-2 bg-muted/50 text-green-600" />
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader className="py-2">
                        <CardTitle className="text-base font-medium text-yellow-600">In Progress</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-3xl font-bold">{inProgressTasks}</div>
                        <Progress value={50} className="h-2 mt-2 bg-muted/50 text-yellow-600" />
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader className="py-2">
                        <CardTitle className="text-base font-medium text-gray-600">To Do</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-3xl font-bold">{pendingTasks}</div>
                        <Progress value={0} className="h-2 mt-2 bg-muted/50" />
                      </CardContent>
                    </Card>
                  </div>
                </div>
                
                {content.topContributors && content.topContributors.length > 0 && (
                  <div className="space-y-4">
                    <h3 className="font-medium">Top Contributors</h3>
                    <div className="space-y-2">
                      {content.topContributors.map((contributor: any, index: number) => (
                        <div key={index} className="flex items-center justify-between p-3 border rounded-md">
                          <div className="flex items-center gap-2">
                            <span className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                              <User className="h-4 w-4" />
                            </span>
                            <div>
                              <div className="font-medium">{contributor.name}</div>
                              <div className="text-sm text-muted-foreground">
                                {contributor.tasks} {contributor.tasks === 1 ? "task" : "tasks"}
                              </div>
                            </div>
                          </div>
                          {contributor.timeSpent !== undefined && (
                            <div className="text-sm flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              <span>
                                {Math.floor(contributor.timeSpent / 60)}h {contributor.timeSpent % 60}m
                              </span>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
                {content.milestoneStatus && (
                  <div className="space-y-4">
                    <h3 className="font-medium">Milestone Status</h3>
                    <div className="space-y-4">
                      {Object.entries(content.milestoneStatus).map(
                        ([key, value]: [string, any], index: number) => (
                          <div key={index} className="space-y-2">
                            <div className="flex justify-between items-center">
                              <div className="font-medium capitalize">
                                {key.replace(/-/g, " ")}
                              </div>
                              <Badge
                                variant={
                                  value === "completed"
                                    ? "default"
                                    : value === "in-progress"
                                    ? "secondary"
                                    : "outline"
                                }
                              >
                                {value.replace(/-/g, " ")}
                              </Badge>
                            </div>
                            <Progress
                              value={
                                value === "completed"
                                  ? 100
                                  : value === "in-progress"
                                  ? 50
                                  : 0
                              }
                              className="h-2"
                            />
                          </div>
                        )
                      )}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="tasks">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ListTodo className="h-5 w-5" />
                  Tasks
                </CardTitle>
                <CardDescription>
                  Detailed breakdown of tasks in the reporting period
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoadingTasks ? (
                  <div className="space-y-4">
                    {[1, 2, 3, 4].map((i) => (
                      <Skeleton key={i} className="h-16 w-full" />
                    ))}
                  </div>
                ) : content.tasks ? (
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <h3 className="font-medium">Completed Tasks</h3>
                      <Separator />
                      <div className="space-y-2">
                        {content.tasks
                          .filter((task: Task) => task.status === "done")
                          .map((task: Task) => (
                            <div
                              key={task.id}
                              className="p-3 border rounded-md bg-green-50/10"
                            >
                              <div className="flex items-center justify-between">
                                <div className="font-medium">{task.name}</div>
                                <Badge variant="outline" className="text-green-600 bg-green-50/50">
                                  Completed
                                </Badge>
                              </div>
                              {task.description && (
                                <p className="text-sm text-muted-foreground mt-1">
                                  {task.description}
                                </p>
                              )}
                              <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                                {task.assignee && (
                                  <div className="flex items-center gap-1">
                                    <User className="h-3 w-3" />
                                    <span>{task.assignee}</span>
                                  </div>
                                )}
                                {task.completedAt && (
                                  <div className="flex items-center gap-1">
                                    <Calendar className="h-3 w-3" />
                                    <span>
                                      {format(new Date(task.completedAt), "MMM d, yyyy")}
                                    </span>
                                  </div>
                                )}
                                {task.timeSpent && (
                                  <div className="flex items-center gap-1">
                                    <Clock className="h-3 w-3" />
                                    <span>
                                      {Math.floor(task.timeSpent / 60)}h {task.timeSpent % 60}m
                                    </span>
                                  </div>
                                )}
                              </div>
                            </div>
                          ))}
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <h3 className="font-medium">In Progress Tasks</h3>
                      <Separator />
                      <div className="space-y-2">
                        {content.tasks
                          .filter((task: Task) => task.status === "in_progress")
                          .map((task: Task) => (
                            <div
                              key={task.id}
                              className="p-3 border rounded-md bg-yellow-50/10"
                            >
                              <div className="flex items-center justify-between">
                                <div className="font-medium">{task.name}</div>
                                <Badge variant="outline" className="text-yellow-600 bg-yellow-50/50">
                                  In Progress
                                </Badge>
                              </div>
                              {task.description && (
                                <p className="text-sm text-muted-foreground mt-1">
                                  {task.description}
                                </p>
                              )}
                              <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                                {task.assignee && (
                                  <div className="flex items-center gap-1">
                                    <User className="h-3 w-3" />
                                    <span>{task.assignee}</span>
                                  </div>
                                )}
                                {task.dueDate && (
                                  <div className="flex items-center gap-1">
                                    <Calendar className="h-3 w-3" />
                                    <span>
                                      Due: {format(new Date(task.dueDate), "MMM d, yyyy")}
                                    </span>
                                  </div>
                                )}
                                {task.timeSpent && (
                                  <div className="flex items-center gap-1">
                                    <Clock className="h-3 w-3" />
                                    <span>
                                      {Math.floor(task.timeSpent / 60)}h {task.timeSpent % 60}m
                                    </span>
                                  </div>
                                )}
                              </div>
                            </div>
                          ))}
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <h3 className="font-medium">To Do Tasks</h3>
                      <Separator />
                      <div className="space-y-2">
                        {content.tasks
                          .filter((task: Task) => task.status === "todo")
                          .map((task: Task) => (
                            <div key={task.id} className="p-3 border rounded-md">
                              <div className="flex items-center justify-between">
                                <div className="font-medium">{task.name}</div>
                                <Badge variant="outline">To Do</Badge>
                              </div>
                              {task.description && (
                                <p className="text-sm text-muted-foreground mt-1">
                                  {task.description}
                                </p>
                              )}
                              <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                                {task.assignee && (
                                  <div className="flex items-center gap-1">
                                    <User className="h-3 w-3" />
                                    <span>{task.assignee}</span>
                                  </div>
                                )}
                                {task.dueDate && (
                                  <div className="flex items-center gap-1">
                                    <Calendar className="h-3 w-3" />
                                    <span>
                                      Due: {format(new Date(task.dueDate), "MMM d, yyyy")}
                                    </span>
                                  </div>
                                )}
                              </div>
                            </div>
                          ))}
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                    <h3 className="text-lg font-medium mb-2">No detailed task information</h3>
                    <p className="text-muted-foreground">
                      This report was generated without including task details based on privacy settings.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="contributors">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  Contributors
                </CardTitle>
                <CardDescription>
                  Team members who contributed to the project during this period
                </CardDescription>
              </CardHeader>
              <CardContent>
                {content.topContributors && content.topContributors.length > 0 ? (
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {content.topContributors.map((contributor: any, index: number) => (
                        <Card key={index}>
                          <CardHeader className="pb-2">
                            <div className="flex items-center gap-3">
                              <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                                <User className="h-6 w-6" />
                              </div>
                              <div>
                                <CardTitle className="text-xl">{contributor.name}</CardTitle>
                                <CardDescription>
                                  {contributor.tasks} {contributor.tasks === 1 ? "task" : "tasks"} assigned
                                </CardDescription>
                              </div>
                            </div>
                          </CardHeader>
                          <CardContent>
                            <div className="space-y-2">
                              {contributor.timeSpent !== undefined && (
                                <div className="flex justify-between items-center py-1 border-b">
                                  <span className="font-medium text-sm">Time Spent</span>
                                  <span className="flex items-center gap-1">
                                    <Clock className="h-3 w-3" />
                                    {Math.floor(contributor.timeSpent / 60)}h {contributor.timeSpent % 60}m
                                  </span>
                                </div>
                              )}
                              <div className="flex justify-between items-center py-1 border-b">
                                <span className="font-medium text-sm">Completed Tasks</span>
                                <span>
                                  {content.tasks
                                    ?.filter(
                                      (task: Task) =>
                                        task.assignee === contributor.name && task.status === "done"
                                    )
                                    .length || "N/A"}
                                </span>
                              </div>
                              <div className="flex justify-between items-center py-1 border-b">
                                <span className="font-medium text-sm">In Progress</span>
                                <span>
                                  {content.tasks
                                    ?.filter(
                                      (task: Task) =>
                                        task.assignee === contributor.name &&
                                        task.status === "in_progress"
                                    )
                                    .length || "N/A"}
                                </span>
                              </div>
                              <div className="flex justify-between items-center py-1">
                                <span className="font-medium text-sm">To Do</span>
                                <span>
                                  {content.tasks
                                    ?.filter(
                                      (task: Task) =>
                                        task.assignee === contributor.name && task.status === "todo"
                                    )
                                    .length || "N/A"}
                                </span>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <User className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                    <h3 className="text-lg font-medium mb-2">No contributor information</h3>
                    <p className="text-muted-foreground">
                      This report was generated without including contributor details based on privacy settings.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}