import { useState } from "react";
import { useLocation } from "wouter";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ChevronLeft, Plus, RefreshCw } from "lucide-react";
import { Link } from "wouter";
import { insertProjectSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { toast } from "@/hooks/use-toast";

// Extend the project schema with validation rules
const projectFormSchema = insertProjectSchema.extend({
  name: z.string().min(3, "Project name must be at least 3 characters"),
});

type ProjectForm = z.infer<typeof projectFormSchema>;

export default function NewProject() {
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState("manual");
  const [isLoading, setIsLoading] = useState(false);

  // Define form with validation schema
  const form = useForm<ProjectForm>({
    resolver: zodResolver(projectFormSchema),
    defaultValues: {
      name: "",
      description: "",
      userId: 1, // Demo user
      externalId: null,
      externalSource: null,
      accessToken: null,
      settings: {}
    }
  });

  async function onSubmit(values: ProjectForm) {
    setIsLoading(true);
    try {
      const newProject = await apiRequest('/api/projects', {
        method: 'POST',
        body: JSON.stringify(values)
      });
      
      toast({
        title: "Project created",
        description: "Your new project has been created successfully."
      });
      
      // Navigate to the project detail page
      navigate(`/projects/${newProject.id}`);
    } catch (error) {
      console.error("Error creating project:", error);
      toast({
        title: "Error creating project",
        description: "There was a problem creating your project. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="container mx-auto py-6">
      <div className="flex items-center mb-2">
        <Link href="/dashboard">
          <Button variant="ghost" size="sm" className="gap-1">
            <ChevronLeft className="h-4 w-4" />
            Back
          </Button>
        </Link>
      </div>

      <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4 mb-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Create New Project</h1>
          <p className="text-muted-foreground">
            Set up a new project to track tasks and generate reports
          </p>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full max-w-md grid-cols-2">
          <TabsTrigger value="manual">Manual Setup</TabsTrigger>
          <TabsTrigger value="integration">Connect Integration</TabsTrigger>
        </TabsList>
        
        <TabsContent value="manual">
          <Card className="max-w-2xl mx-auto">
            <CardHeader>
              <CardTitle>Project Details</CardTitle>
              <CardDescription>
                Create a project to organize your tasks and generate progress reports
              </CardDescription>
            </CardHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)}>
                <CardContent className="space-y-6">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Project Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter project name" {...field} />
                        </FormControl>
                        <FormDescription>
                          Choose a descriptive name for your project
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Describe the project and its goals"
                            {...field}
                            value={field.value || ""}
                          />
                        </FormControl>
                        <FormDescription>
                          Provide details about the project's purpose and objectives
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button variant="outline" type="button" onClick={() => navigate("/dashboard")}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={isLoading}>
                    {isLoading ? (
                      <>
                        <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                        Creating...
                      </>
                    ) : (
                      <>
                        <Plus className="mr-2 h-4 w-4" />
                        Create Project
                      </>
                    )}
                  </Button>
                </CardFooter>
              </form>
            </Form>
          </Card>
        </TabsContent>
        
        <TabsContent value="integration">
          <Card className="max-w-2xl mx-auto">
            <CardHeader>
              <CardTitle>Connect to External Service</CardTitle>
              <CardDescription>
                Import an existing project from a supported project management tool
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div>
                  <FormLabel>Service</FormLabel>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a service" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="trello">Trello</SelectItem>
                      <SelectItem value="asana">Asana</SelectItem>
                      <SelectItem value="jira">Jira</SelectItem>
                      <SelectItem value="github">GitHub</SelectItem>
                      <SelectItem value="monday">Monday.com</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-sm text-muted-foreground mt-2">
                    Choose the service where your existing project is hosted
                  </p>
                </div>
                
                <div>
                  <FormLabel>Authentication</FormLabel>
                  <div className="p-8 border rounded-md flex flex-col items-center justify-center">
                    <p className="text-center text-muted-foreground mb-4">
                      You need to authenticate with the selected service to access your projects
                    </p>
                    <Button>
                      Connect Account
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" type="button" onClick={() => navigate("/dashboard")}>
                Cancel
              </Button>
              <Button disabled>
                <Plus className="mr-2 h-4 w-4" />
                Continue
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}