import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import { DatePickerWithRange } from "@/components/ui/date-picker-with-range";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ChevronLeft, FileText, RefreshCw } from "lucide-react";
import { Link } from "wouter";
import { Project, PrivacySettings } from "@shared/schema";
import { toast } from "@/hooks/use-toast";

export default function GenerateReport() {
  const [, navigate] = useLocation();
  const userId = 1; // For demo purposes
  
  const [selectedProjectId, setSelectedProjectId] = useState<string>("");
  const [reportTitle, setReportTitle] = useState("");
  const [dateRange, setDateRange] = useState({
    from: new Date(),
    to: new Date(new Date().setDate(new Date().getDate() + 7))
  });
  const [isPrivate, setIsPrivate] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  
  const { data: projects, isLoading: isLoadingProjects } = useQuery({
    queryKey: ["/api/projects", userId],
    queryFn: async () => {
      const response = await fetch(`/api/projects?userId=${userId}`);
      if (!response.ok) {
        throw new Error("Failed to fetch projects");
      }
      return response.json() as Promise<Project[]>;
    }
  });
  
  const { data: privacySettings } = useQuery({
    queryKey: ["/api/privacy-settings", userId],
    queryFn: async () => {
      try {
        const response = await fetch(`/api/privacy-settings?userId=${userId}`);
        if (!response.ok) {
          throw new Error("Failed to fetch privacy settings");
        }
        return response.json() as Promise<PrivacySettings>;
      } catch (error) {
        console.error("Error fetching privacy settings:", error);
        return null;
      }
    }
  });
  
  // Set default report privacy based on user settings
  useEffect(() => {
    if (privacySettings) {
      setIsPrivate(privacySettings.defaultReportPrivacy);
    }
  }, [privacySettings]);
  
  // Update report title when project selection changes
  useEffect(() => {
    if (selectedProjectId && projects) {
      const project = projects.find(p => p.id.toString() === selectedProjectId);
      if (project) {
        setReportTitle(`${project.name} - Weekly Progress Report`);
      }
    }
  }, [selectedProjectId, projects]);
  
  const handleGenerateReport = async () => {
    if (!selectedProjectId || !dateRange.from || !dateRange.to || !reportTitle) {
      toast({
        title: "Missing information",
        description: "Please fill out all fields to generate a report.",
        variant: "destructive"
      });
      return;
    }
    
    setIsGenerating(true);
    
    try {
      const response = await fetch(`/api/projects/${selectedProjectId}/generate-report`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          title: reportTitle,
          startDate: dateRange.from.toISOString(),
          endDate: dateRange.to.toISOString(),
          isPrivate
        })
      });
      
      if (!response.ok) {
        throw new Error("Failed to generate report");
      }
      
      const data = await response.json();
      
      toast({
        title: "Report generated successfully",
        description: "Your progress report has been created and is ready to view."
      });
      
      // Navigate to the report detail page
      navigate(`/reports/${data.id}`);
    } catch (error) {
      console.error("Error generating report:", error);
      
      toast({
        title: "Error generating report",
        description: "There was a problem creating your report. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsGenerating(false);
    }
  };
  
  return (
    <div className="container mx-auto py-6">
      <div className="max-w-3xl mx-auto">
        <div className="flex items-center mb-2">
          <Link href="/dashboard">
            <Button variant="ghost" size="sm" className="gap-1">
              <ChevronLeft className="h-4 w-4" />
              Back
            </Button>
          </Link>
        </div>
        
        <div className="mb-6">
          <h1 className="text-3xl font-bold tracking-tight">Generate Progress Report</h1>
          <p className="text-muted-foreground">
            Create a new report summarizing project progress and activity
          </p>
        </div>
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Report Configuration
            </CardTitle>
            <CardDescription>
              Select a project and date range to generate a detailed progress report
            </CardDescription>
          </CardHeader>
          
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="project">Project</Label>
              {isLoadingProjects ? (
                <Skeleton className="h-10 w-full" />
              ) : (
                <Select
                  value={selectedProjectId}
                  onValueChange={setSelectedProjectId}
                >
                  <SelectTrigger id="project">
                    <SelectValue placeholder="Select a project" />
                  </SelectTrigger>
                  <SelectContent>
                    {projects && projects.length > 0 ? (
                      projects.map((project) => (
                        <SelectItem key={project.id} value={project.id.toString()}>
                          {project.name}
                        </SelectItem>
                      ))
                    ) : (
                      <SelectItem value="no-projects" disabled>
                        No projects available
                      </SelectItem>
                    )}
                  </SelectContent>
                </Select>
              )}
              <p className="text-sm text-muted-foreground">
                Choose the project for which you want to generate a report
              </p>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="title">Report Title</Label>
              <Input
                id="title"
                value={reportTitle}
                onChange={(e) => setReportTitle(e.target.value)}
                placeholder="Enter report title"
              />
              <p className="text-sm text-muted-foreground">
                Add a descriptive title for your report
              </p>
            </div>
            
            <div className="space-y-2">
              <Label>Date Range</Label>
              <DatePickerWithRange
                date={{
                  from: dateRange.from,
                  to: dateRange.to
                }}
                setDate={(range) => {
                  if (range?.from && range?.to) {
                    setDateRange({ from: range.from, to: range.to });
                  }
                }}
              />
              <p className="text-sm text-muted-foreground">
                Select the time period to include in the report
              </p>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Switch
                  id="private"
                  checked={isPrivate}
                  onCheckedChange={setIsPrivate}
                />
                <Label htmlFor="private">Make report private</Label>
              </div>
              <p className="text-sm text-muted-foreground">
                Private reports are only visible to you and cannot be shared with others
              </p>
            </div>
            
            <div className="space-y-2 border rounded-md p-4 bg-muted/50">
              <h3 className="font-medium">Privacy Settings</h3>
              <p className="text-sm text-muted-foreground">
                This report will be generated according to your privacy preferences:
              </p>
              <ul className="text-sm space-y-1 mt-2">
                <li className="flex items-center gap-2">
                  <span className="text-muted-foreground">Show Time Spent:</span>
                  <span>{privacySettings?.showTimeSpent ? "Yes" : "No"}</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-muted-foreground">Show Assignees:</span>
                  <span>{privacySettings?.showAssigneeNames ? "Yes" : "No"}</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-muted-foreground">Include Task Details:</span>
                  <span>{privacySettings?.includeTaskDetails ? "Yes" : "No"}</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-muted-foreground">Include Private Tasks:</span>
                  <span>{privacySettings?.includePrivateTasks ? "Yes" : "No"}</span>
                </li>
              </ul>
              <div className="mt-2">
                <Link href="/privacy-settings">
                  <Button variant="link" className="p-0 h-auto text-sm">
                    Adjust privacy settings
                  </Button>
                </Link>
              </div>
            </div>
          </CardContent>
          
          <CardFooter className="flex justify-between">
            <Button variant="outline" onClick={() => navigate("/dashboard")}>
              Cancel
            </Button>
            <Button
              onClick={handleGenerateReport}
              disabled={isGenerating || !selectedProjectId || !reportTitle}
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                  Generating...
                </>
              ) : (
                "Generate Report"
              )}
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}