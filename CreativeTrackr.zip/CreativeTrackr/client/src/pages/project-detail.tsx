import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Project, Task, PrivacySettings } from "@shared/schema";
import { useRoute } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar, ChevronLeft, Clock, FileText, Plus, RefreshCw, Settings, Shield } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { DatePickerWithRange } from "@/components/ui/date-picker-with-range";
import { Switch } from "@/components/ui/switch";
import { toast } from "@/hooks/use-toast";

export default function ProjectDetail() {
  const [, params] = useRoute("/projects/:id");
  const projectId = parseInt(params?.id || "1");
  const userId = 1; // For demo purposes

  const [activeTab, setActiveTab] = useState("tasks");
  const [dateRange, setDateRange] = useState({
    from: new Date(),
    to: new Date(new Date().setDate(new Date().getDate() + 7))
  });
  const [isPrivate, setIsPrivate] = useState(false);
  const [reportTitle, setReportTitle] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [openDialog, setOpenDialog] = useState(false);

  const { data: project, isLoading: isLoadingProject } = useQuery({
    queryKey: ["/api/projects", projectId],
    queryFn: async () => {
      const response = await fetch(`/api/projects/${projectId}`);
      if (!response.ok) {
        throw new Error("Failed to fetch project");
      }
      return response.json() as Promise<Project>;
    }
  });

  const { data: tasks, isLoading: isLoadingTasks } = useQuery({
    queryKey: ["/api/tasks", projectId],
    queryFn: async () => {
      const response = await fetch(`/api/tasks?projectId=${projectId}&includePrivate=true`);
      if (!response.ok) {
        throw new Error("Failed to fetch tasks");
      }
      return response.json() as Promise<Task[]>;
    }
  });

  const { data: privacySettings } = useQuery({
    queryKey: ["/api/privacy-settings", userId],
    queryFn: async () => {
      try {
        const response = await fetch(`/api/privacy-settings?userId=${userId}`);
        if (!response.ok) {
          throw new Error("Failed to fetch privacy settings");
        }
        return response.json() as Promise<PrivacySettings>;
      } catch (error) {
        console.error("Error fetching privacy settings:", error);
        return null;
      }
    }
  });

  useEffect(() => {
    if (privacySettings) {
      setIsPrivate(privacySettings.defaultReportPrivacy);
    }
  }, [privacySettings]);

  useEffect(() => {
    if (project) {
      setReportTitle(`${project.name} - Weekly Progress Report`);
    }
  }, [project]);

  const handleGenerateReport = async () => {
    if (!dateRange.from || !dateRange.to || !reportTitle) {
      toast({
        title: "Missing information",
        description: "Please fill out all fields to generate a report.",
        variant: "destructive"
      });
      return;
    }

    setIsGenerating(true);

    try {
      const response = await fetch(`/api/projects/${projectId}/generate-report`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          title: reportTitle,
          startDate: dateRange.from.toISOString(),
          endDate: dateRange.to.toISOString(),
          isPrivate
        })
      });

      if (!response.ok) {
        throw new Error("Failed to generate report");
      }

      const data = await response.json();
      setOpenDialog(false);
      toast({
        title: "Report generated successfully",
        description: "Your progress report has been created and is ready to view."
      });
    } catch (error) {
      console.error("Error generating report:", error);
      toast({
        title: "Error generating report",
        description: "There was a problem creating your report. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsGenerating(false);
    }
  };

  if (isLoadingProject) {
    return (
      <div className="container mx-auto py-6">
        <div className="flex items-center mb-6">
          <Skeleton className="h-8 w-8 mr-2 rounded-full" />
          <Skeleton className="h-8 w-48" />
        </div>
        <Skeleton className="h-8 w-full max-w-md mb-4" />
        <Skeleton className="h-4 w-full max-w-sm mb-8" />

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-32 rounded-md" />
          ))}
        </div>

        <Skeleton className="h-12 w-full max-w-md mb-6" />

        <Skeleton className="h-[600px] w-full rounded-md" />
      </div>
    );
  }

  if (!project) {
    return (
      <div className="container mx-auto py-6 text-center">
        <h1 className="text-2xl font-bold mb-2">Project not found</h1>
        <p className="text-muted-foreground mb-6">
          The project you're looking for doesn't exist or has been removed.
        </p>
        <Link href="/dashboard">
          <Button>
            <ChevronLeft className="mr-2 h-4 w-4" />
            Back to Dashboard
          </Button>
        </Link>
      </div>
    );
  }

  // Calculate task statistics
  const totalTasks = tasks?.length || 0;
  const completedTasks = tasks?.filter(task => task.status === "done").length || 0;
  const inProgressTasks = tasks?.filter(task => task.status === "in_progress").length || 0;
  const todoTasks = tasks?.filter(task => task.status === "todo").length || 0;
  const completionPercentage = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

  // Calculate total time spent
  const totalTimeSpent = tasks?.reduce((acc, task) => acc + (task.timeSpent || 0), 0) || 0;
  const totalHours = Math.floor(totalTimeSpent / 60);
  const totalMinutes = totalTimeSpent % 60;

  return (
    <div className="container mx-auto py-6">
      <div className="flex items-center mb-2">
        <Link href="/dashboard">
          <Button variant="ghost" size="sm" className="gap-1">
            <ChevronLeft className="h-4 w-4" />
            Back
          </Button>
        </Link>
      </div>

      <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4 mb-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{project.name}</h1>
          <p className="text-muted-foreground">
            {project.description || "No description provided"}
          </p>
          {project.externalSource && (
            <Badge variant="outline" className="mt-2">
              Connected to {project.externalSource}
            </Badge>
          )}
        </div>

        <div className="flex flex-wrap gap-2">
          <Dialog open={openDialog} onOpenChange={setOpenDialog}>
            <DialogTrigger asChild>
              <Button>
                <FileText className="mr-2 h-4 w-4" />
                Generate Report
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>Generate Progress Report</DialogTitle>
                <DialogDescription>
                  Create a new report for {project.name} based on task data within the selected date range.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="title" className="text-right">
                    Title
                  </Label>
                  <Input
                    id="title"
                    value={reportTitle}
                    onChange={(e) => setReportTitle(e.target.value)}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label className="text-right">Date Range</Label>
                  <div className="col-span-3">
                    <DatePickerWithRange
                      date={{
                        from: dateRange.from,
                        to: dateRange.to
                      }}
                      setDate={(range) => {
                        if (range?.from && range?.to) {
                          setDateRange({ from: range.from, to: range.to });
                        }
                      }}
                    />
                  </div>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="private" className="text-right">
                    Private Report
                  </Label>
                  <div className="flex items-center gap-2 col-span-3">
                    <Switch
                      id="private"
                      checked={isPrivate}
                      onCheckedChange={setIsPrivate}
                    />
                    <Label htmlFor="private" className="text-sm text-muted-foreground">
                      {isPrivate
                        ? "This report will only be visible to you"
                        : "This report can be shared with others"}
                    </Label>
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setOpenDialog(false)}>
                  Cancel
                </Button>
                <Button onClick={handleGenerateReport} disabled={isGenerating}>
                  {isGenerating ? (
                    <>
                      <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    "Generate Report"
                  )}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          <Button variant="outline">
            <Plus className="mr-2 h-4 w-4" />
            Add Task
          </Button>

          <Button variant="outline">
            <RefreshCw className="mr-2 h-4 w-4" />
            Sync
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Completion</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{completionPercentage}%</div>
            <Progress
              value={completionPercentage}
              className="h-2 mt-2"
            />
            <p className="text-xs text-muted-foreground mt-2">
              {completedTasks} of {totalTasks} tasks completed
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Tasks</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalTasks}</div>
            <div className="text-xs text-muted-foreground mt-1 space-y-1">
              <div className="flex justify-between">
                <span>Completed:</span>
                <span className="font-medium">{completedTasks}</span>
              </div>
              <div className="flex justify-between">
                <span>In Progress:</span>
                <span className="font-medium">{inProgressTasks}</span>
              </div>
              <div className="flex justify-between">
                <span>To Do:</span>
                <span className="font-medium">{todoTasks}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Time Spent</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {totalHours}h {totalMinutes}m
            </div>
            <div className="flex items-center mt-2 text-xs text-muted-foreground">
              <Clock className="h-3 w-3 mr-1" />
              <span>Total hours tracked</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Last Updated</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {new Date(project.updatedAt).toLocaleDateString()}
            </div>
            <div className="flex items-center mt-2 text-xs text-muted-foreground">
              <Calendar className="h-3 w-3 mr-1" />
              <span>{new Date(project.updatedAt).toLocaleTimeString()}</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <div className="flex justify-between items-center">
          <TabsList>
            <TabsTrigger value="tasks">Tasks</TabsTrigger>
            <TabsTrigger value="reports">Reports</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          {activeTab === "tasks" && (
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="gap-1">
                <Shield className="h-3 w-3" />
                Privacy: {privacySettings?.includePrivateTasks ? "Show private tasks" : "Hide private tasks"}
              </Badge>
            </div>
          )}
        </div>

        <TabsContent value="tasks" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Task List</CardTitle>
              <CardDescription>
                Manage and track all tasks associated with this project
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingTasks ? (
                <div className="space-y-4">
                  {[1, 2, 3, 4].map((i) => (
                    <Skeleton key={i} className="h-16 w-full" />
                  ))}
                </div>
              ) : tasks && tasks.length > 0 ? (
                <ScrollArea className="h-[400px]">
                  <div className="space-y-4">
                    {tasks.map((task) => (
                      <div
                        key={task.id}
                        className="flex items-start justify-between p-4 border rounded-md"
                      >
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-medium">{task.name}</span>
                            {task.isPrivate && (
                              <Badge variant="secondary" className="text-xs">Private</Badge>
                            )}
                            <Badge variant="outline" className="text-xs">
                              {task.status === "done"
                                ? "Completed"
                                : task.status === "in_progress"
                                ? "In Progress"
                                : "To Do"}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mt-1">
                            {task.description || "No description provided"}
                          </p>
                          <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                            {task.assignee && (
                              <div className="flex items-center gap-1">
                                <span>Assignee: {task.assignee}</span>
                              </div>
                            )}
                            {task.timeSpent && (
                              <div className="flex items-center gap-1">
                                <Clock className="h-3 w-3" />
                                <span>
                                  {Math.floor(task.timeSpent / 60)}h {task.timeSpent % 60}m
                                </span>
                              </div>
                            )}
                            {task.dueDate && (
                              <div className="flex items-center gap-1">
                                <Calendar className="h-3 w-3" />
                                <span>Due: {new Date(task.dueDate).toLocaleDateString()}</span>
                              </div>
                            )}
                          </div>
                        </div>
                        <div>
                          <Button variant="ghost" size="sm">
                            <Settings className="h-4 w-4" />
                            <span className="sr-only">Task settings</span>
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              ) : (
                <div className="text-center py-12">
                  <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium mb-2">No tasks found</h3>
                  <p className="text-muted-foreground mb-4">
                    This project doesn't have any tasks yet.
                  </p>
                  <Button>Add your first task</Button>
                </div>
              )}
            </CardContent>
            <CardFooter className="border-t bg-muted/50 px-6 py-3">
              <div className="flex justify-between w-full text-sm">
                <span>Showing {tasks?.length || 0} tasks</span>
                <Button variant="link" className="p-0 h-auto">Refresh</Button>
              </div>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="reports" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Project Reports</CardTitle>
              <CardDescription>
                View and download reports generated for this project
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium mb-2">No reports generated yet</h3>
                <p className="text-muted-foreground mb-4">
                  Generate your first progress report to track and share updates.
                </p>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button>Generate a Report</Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-[500px]">
                    {/* Same dialog content as above */}
                  </DialogContent>
                </Dialog>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Project Settings</CardTitle>
              <CardDescription>
                Manage project configuration and privacy settings
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-medium mb-2">General Settings</h3>
                <Separator className="mb-4" />
                <div className="space-y-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="project-name" className="text-right">
                      Project Name
                    </Label>
                    <Input
                      id="project-name"
                      defaultValue={project.name}
                      className="col-span-3"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="project-description" className="text-right">
                      Description
                    </Label>
                    <Input
                      id="project-description"
                      defaultValue={project.description || ""}
                      className="col-span-3"
                    />
                  </div>
                </div>
              </div>

              <div>
                <h3 className="font-medium mb-2">Integration Settings</h3>
                <Separator className="mb-4" />
                <div className="space-y-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label className="text-right">External Source</Label>
                    <div className="col-span-3">
                      {project.externalSource ? (
                        <Badge variant="outline">{project.externalSource}</Badge>
                      ) : (
                        <span className="text-muted-foreground">No external source connected</span>
                      )}
                    </div>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <div className="col-span-4 flex justify-end">
                      <Button variant="outline">
                        <Settings className="mr-2 h-4 w-4" />
                        Manage Integration
                      </Button>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="font-medium mb-2">Privacy Settings</h3>
                <Separator className="mb-4" />
                <div className="space-y-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="include-private-tasks" className="text-right">
                      Include Private Tasks
                    </Label>
                    <div className="flex items-center gap-2 col-span-3">
                      <Switch
                        id="include-private-tasks"
                        defaultChecked={privacySettings?.includePrivateTasks}
                      />
                      <Label htmlFor="include-private-tasks" className="text-sm text-muted-foreground">
                        Include private tasks in generated reports
                      </Label>
                    </div>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="show-assignees" className="text-right">
                      Show Assignees
                    </Label>
                    <div className="flex items-center gap-2 col-span-3">
                      <Switch
                        id="show-assignees"
                        defaultChecked={privacySettings?.showAssigneeNames}
                      />
                      <Label htmlFor="show-assignees" className="text-sm text-muted-foreground">
                        Show assignee names in generated reports
                      </Label>
                    </div>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="show-time-spent" className="text-right">
                      Show Time Spent
                    </Label>
                    <div className="flex items-center gap-2 col-span-3">
                      <Switch
                        id="show-time-spent"
                        defaultChecked={privacySettings?.showTimeSpent}
                      />
                      <Label htmlFor="show-time-spent" className="text-sm text-muted-foreground">
                        Show time tracking data in generated reports
                      </Label>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end gap-2">
              <Button variant="outline">Cancel</Button>
              <Button>Save Changes</Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}