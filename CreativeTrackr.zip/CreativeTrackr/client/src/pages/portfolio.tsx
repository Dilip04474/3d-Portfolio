import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import HeroSection from "@/components/ui/hero-section";
import AboutSection from "@/components/ui/about-section";
import ProcessSection from "@/components/ui/process-section";
import ContactSection from "@/components/ui/contact-section";
import { useEffect, useState } from "react";
import { motion } from "framer-motion";

// Mock projects data (normally would come from an API)
const projects = [
  {
    id: 1,
    title: "Geometric Harmony",
    category: "3D Modeling",
    description: "An exploration of geometric shapes and light interaction in a minimalist environment.",
    year: "2023",
    tools: "Cinema 4D, Octane"
  },
  {
    id: 2,
    title: "Neon Dreams",
    category: "Environment",
    description: "A cyberpunk-inspired interior space featuring volumetric lighting and realistic materials.",
    year: "2023",
    tools: "Blender, EEVEE"
  },
  {
    id: 3,
    title: "Liquid Motion",
    category: "Animation",
    description: "A fluid simulation study exploring dynamic motion and physical properties.",
    year: "2022",
    tools: "Houdini, Redshift"
  },
  {
    id: 4,
    title: "Urban Sanctuary",
    category: "Architecture",
    description: "An architectural visualization showcasing modern design principles and materials.",
    year: "2023",
    tools: "3ds Max, V-Ray"
  },
  {
    id: 5,
    title: "Astral Gateway",
    category: "Concept Art",
    description: "A science fiction environment exploring themes of technology and interstellar travel.",
    year: "2022",
    tools: "ZBrush, Maya, Arnold"
  },
  {
    id: 6,
    title: "Digital Genesis",
    category: "Abstract",
    description: "An experimental piece exploring generative algorithms and procedural texturing.",
    year: "2023",
    tools: "Blender, Processing"
  }
];

export default function Portfolio() {
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY);
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black text-white font-sans overflow-x-hidden">
      <Header scrollY={scrollY} />
      
      <main>
        <HeroSection />
        
        <section id="work" className="py-20 px-6 max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <motion.h2 
              className="text-4xl font-bold mb-3"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              Featured Work
            </motion.h2>
            <motion.p 
              className="text-gray-400 max-w-2xl mx-auto"
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              A selection of my best 3D projects and creations that showcase different techniques, styles, and concepts.
            </motion.p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project, index) => (
              <motion.div
                key={project.id}
                className="rounded-2xl overflow-hidden bg-gray-900 border border-gray-800 hover:shadow-lg hover:shadow-blue-500/10 transition-all duration-300"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ 
                  duration: 0.5, 
                  delay: index * 0.1,
                  ease: "easeOut"
                }}
                whileHover={{ y: -8 }}
              >
                <div className="relative group">
                  <div className="w-full h-60 bg-gray-800">
                    {/* Default art SVG */}
                    <svg className="w-full h-full object-cover" viewBox="0 0 400 240" xmlns="http://www.w3.org/2000/svg">
                      <defs>
                        <linearGradient id={`grad-${project.id}`} x1="0%" y1="0%" x2="100%" y2="100%">
                          <stop offset="0%" stopColor="#2a3f5f" />
                          <stop offset="100%" stopColor="#3B82F6" />
                        </linearGradient>
                      </defs>
                      <rect width="100%" height="100%" fill={`url(#grad-${project.id})`} />
                      <circle cx="200" cy="120" r="50" fill="rgba(255,255,255,0.1)" />
                      <path d="M150 80 L200 40 L250 80 Z" fill="rgba(255,255,255,0.2)" />
                      <rect x="160" y="140" width="80" height="40" rx="5" fill="rgba(255,255,255,0.15)" />
                      <text x="200" y="165" fontSize="12" textAnchor="middle" fill="white">{project.title}</text>
                    </svg>
                  </div>
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end justify-start p-6">
                    <button className="bg-white/20 backdrop-blur-sm text-white py-2 px-4 rounded-md hover:bg-white/30 transition-colors duration-300 flex items-center gap-2">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <circle cx="12" cy="12" r="10"></circle>
                        <circle cx="12" cy="12" r="3"></circle>
                      </svg>
                      View Details
                    </button>
                  </div>
                </div>
                <div className="p-6">
                  <div className="flex justify-between items-start mb-3">
                    <h3 className="text-xl font-semibold">{project.title}</h3>
                    <span className="text-xs bg-blue-500/20 text-blue-400 px-2 py-1 rounded-full">{project.category}</span>
                  </div>
                  <p className="text-gray-400 text-sm mb-4">{project.description}</p>
                  <div className="flex items-center text-gray-500 text-sm">
                    <span className="flex items-center mr-4">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <circle cx="12" cy="12" r="10"></circle>
                        <polyline points="12 6 12 12 16 14"></polyline>
                      </svg>
                      {project.year}
                    </span>
                    <span className="flex items-center">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"></path>
                      </svg>
                      {project.tools}
                    </span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
          
          <div className="text-center mt-16">
            <motion.button
              className="group relative inline-flex items-center justify-center px-6 py-3 overflow-hidden font-medium border border-gray-700 rounded-md hover:border-white transition-colors duration-300"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.4 }}
            >
              <span className="absolute inset-0 w-full h-full transition-all duration-300 ease-out opacity-0 bg-gradient-to-r from-blue-500/20 via-blue-500/0 to-transparent group-hover:opacity-100"></span>
              <span className="relative flex items-center">
                View All Projects
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2 group-hover:translate-x-1 transition-transform" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="5" y1="12" x2="19" y2="12"></line>
                  <polyline points="12 5 19 12 12 19"></polyline>
                </svg>
              </span>
            </motion.button>
          </div>
        </section>
        
        <AboutSection />
        
        <ProcessSection />
        
        <ContactSection />
      </main>
      
      <Footer />
    </div>
  );
}
