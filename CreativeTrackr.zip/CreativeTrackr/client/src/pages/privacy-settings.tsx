import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { ChevronLeft, RefreshCw, Shield } from "lucide-react";
import { Link } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import { toast } from "@/hooks/use-toast";
import { PrivacySettings, insertPrivacySettingsSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

export default function PrivacySettingsPage() {
  // For demo purposes, we'll use userId 1
  const userId = 1;
  const queryClient = useQueryClient();
  
  const [settings, setSettings] = useState<Partial<PrivacySettings>>({
    showTimeSpent: true,
    showAssigneeNames: true,
    includeTaskDetails: true,
    includePrivateTasks: false,
    defaultReportPrivacy: false
  });
  
  const { data, isLoading, error } = useQuery({
    queryKey: ["/api/privacy-settings", userId],
    queryFn: async () => {
      try {
        const response = await fetch(`/api/privacy-settings?userId=${userId}`);
        if (response.status === 404) {
          // Settings don't exist yet, create default ones
          return null;
        }
        if (!response.ok) {
          throw new Error("Failed to fetch privacy settings");
        }
        return response.json() as Promise<PrivacySettings>;
      } catch (error) {
        console.error("Error fetching privacy settings:", error);
        return null;
      }
    }
  });
  
  // Set settings when data is loaded
  useEffect(() => {
    if (data) {
      setSettings({
        showTimeSpent: data.showTimeSpent,
        showAssigneeNames: data.showAssigneeNames,
        includeTaskDetails: data.includeTaskDetails,
        includePrivateTasks: data.includePrivateTasks,
        defaultReportPrivacy: data.defaultReportPrivacy
      });
    }
  }, [data]);
  
  const saveSettingsMutation = useMutation({
    mutationFn: async (newSettings: typeof settings) => {
      return apiRequest('/api/privacy-settings', {
        method: 'POST',
        body: JSON.stringify({
          ...newSettings,
          userId
        })
      });
    },
    onSuccess: () => {
      toast({
        title: "Settings saved",
        description: "Your privacy preferences have been updated successfully."
      });
      queryClient.invalidateQueries({ queryKey: ["/api/privacy-settings", userId] });
    },
    onError: (error) => {
      console.error("Error saving settings:", error);
      toast({
        title: "Error saving settings",
        description: "There was a problem updating your privacy settings. Please try again.",
        variant: "destructive"
      });
    }
  });
  
  const handleSaveSettings = () => {
    saveSettingsMutation.mutate(settings);
  };
  
  if (isLoading) {
    return (
      <div className="container mx-auto py-6">
        <div className="max-w-3xl mx-auto">
          <div className="flex items-center mb-2">
            <Skeleton className="h-10 w-20" />
          </div>
          <div className="mb-6">
            <Skeleton className="h-10 w-64 mb-2" />
            <Skeleton className="h-5 w-96" />
          </div>
          <Card>
            <CardHeader>
              <Skeleton className="h-8 w-48 mb-2" />
              <Skeleton className="h-4 w-full" />
            </CardHeader>
            <CardContent className="space-y-8">
              {[1, 2, 3, 4, 5].map((i) => (
                <div key={i} className="space-y-4">
                  <Skeleton className="h-5 w-32" />
                  <Skeleton className="h-4 w-full" />
                  <div className="flex items-center space-x-2">
                    <Skeleton className="h-5 w-10 rounded-full" />
                    <Skeleton className="h-4 w-52" />
                  </div>
                </div>
              ))}
            </CardContent>
            <CardFooter>
              <Skeleton className="h-10 w-24 ml-auto" />
            </CardFooter>
          </Card>
        </div>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto py-6">
      <div className="max-w-3xl mx-auto">
        <div className="flex items-center mb-2">
          <Link href="/dashboard">
            <Button variant="ghost" size="sm" className="gap-1">
              <ChevronLeft className="h-4 w-4" />
              Back
            </Button>
          </Link>
        </div>
        
        <div className="mb-6">
          <h1 className="text-3xl font-bold tracking-tight">Privacy Settings</h1>
          <p className="text-muted-foreground">
            Control how your data is handled in reports and shared with others
          </p>
        </div>
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5" />
              Data Privacy Controls
            </CardTitle>
            <CardDescription>
              These settings apply to all projects and reports you create in the system
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-8">
            <div className="space-y-4">
              <h3 className="font-medium">Time Tracking</h3>
              <Separator />
              <div className="flex flex-col gap-6">
                <div className="flex items-start space-x-4">
                  <Switch
                    id="show-time-spent"
                    checked={settings.showTimeSpent}
                    onCheckedChange={(checked) => 
                      setSettings({...settings, showTimeSpent: checked})
                    }
                  />
                  <div className="space-y-1">
                    <Label
                      htmlFor="show-time-spent"
                      className="text-base font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Show time spent in reports
                    </Label>
                    <p className="text-sm text-muted-foreground">
                      When enabled, the total time spent on tasks will be visible in generated reports.
                      When disabled, reports will show task completion but hide time tracking data.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="space-y-4">
              <h3 className="font-medium">Assignee Information</h3>
              <Separator />
              <div className="flex flex-col gap-6">
                <div className="flex items-start space-x-4">
                  <Switch
                    id="show-assignee-names"
                    checked={settings.showAssigneeNames}
                    onCheckedChange={(checked) => 
                      setSettings({...settings, showAssigneeNames: checked})
                    }
                  />
                  <div className="space-y-1">
                    <Label
                      htmlFor="show-assignee-names"
                      className="text-base font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Show assignee names in reports
                    </Label>
                    <p className="text-sm text-muted-foreground">
                      When enabled, reports will show which team members are assigned to tasks.
                      When disabled, reports will only show task counts without attribution.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="space-y-4">
              <h3 className="font-medium">Task Details</h3>
              <Separator />
              <div className="flex flex-col gap-6">
                <div className="flex items-start space-x-4">
                  <Switch
                    id="include-task-details"
                    checked={settings.includeTaskDetails}
                    onCheckedChange={(checked) => 
                      setSettings({...settings, includeTaskDetails: checked})
                    }
                  />
                  <div className="space-y-1">
                    <Label
                      htmlFor="include-task-details"
                      className="text-base font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Include detailed task information
                    </Label>
                    <p className="text-sm text-muted-foreground">
                      When enabled, reports will include full descriptions and details for each task.
                      When disabled, reports will only include task names and status.
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <Switch
                    id="include-private-tasks"
                    checked={settings.includePrivateTasks}
                    onCheckedChange={(checked) => 
                      setSettings({...settings, includePrivateTasks: checked})
                    }
                  />
                  <div className="space-y-1">
                    <Label
                      htmlFor="include-private-tasks"
                      className="text-base font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Include private tasks in reports
                    </Label>
                    <p className="text-sm text-muted-foreground">
                      When enabled, tasks marked as private will be included in generated reports.
                      When disabled, private tasks will be excluded from reports entirely.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="space-y-4">
              <h3 className="font-medium">Report Sharing</h3>
              <Separator />
              <div className="flex flex-col gap-6">
                <div className="flex items-start space-x-4">
                  <Switch
                    id="default-report-privacy"
                    checked={settings.defaultReportPrivacy}
                    onCheckedChange={(checked) => 
                      setSettings({...settings, defaultReportPrivacy: checked})
                    }
                  />
                  <div className="space-y-1">
                    <Label
                      htmlFor="default-report-privacy"
                      className="text-base font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Make reports private by default
                    </Label>
                    <p className="text-sm text-muted-foreground">
                      When enabled, all newly generated reports will be private by default.
                      When disabled, reports will be shareable unless marked private.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button
              className="ml-auto"
              onClick={handleSaveSettings}
              disabled={saveSettingsMutation.isPending}
            >
              {saveSettingsMutation.isPending ? (
                <>
                  <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : (
                "Save Settings"
              )}
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}