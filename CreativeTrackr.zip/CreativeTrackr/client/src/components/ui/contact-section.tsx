import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";

export default function ContactSection() {
  return (
    <section id="contact" className="py-24 px-6 bg-gradient-to-r from-blue-500/20 to-purple-800/20 backdrop-blur">
      <motion.div 
        className="max-w-4xl mx-auto text-center"
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5 }}
      >
        <h2 className="text-4xl font-bold mb-6">Ready to bring your vision to life?</h2>
        <p className="text-xl text-gray-300 mb-10 max-w-3xl mx-auto">
          Let's collaborate on your next project and create something extraordinary together.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <motion.div
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Button 
              className="px-8 py-4 h-auto bg-blue-500 text-white rounded-lg font-medium hover:bg-blue-600 transition-colors duration-300 w-full sm:w-auto"
            >
              Start a Project
            </Button>
          </motion.div>
          <motion.div
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Button 
              variant="outline"
              className="px-8 py-4 h-auto bg-transparent border border-white text-white rounded-lg font-medium hover:bg-white/10 transition-colors duration-300 w-full sm:w-auto"
            >
              View Process
            </Button>
          </motion.div>
        </div>
      </motion.div>
    </section>
  );
}
