import { motion } from "framer-motion";

export default function ProcessSection() {
  const steps = [
    {
      number: "01",
      title: "Concept & Research",
      description: "Every project begins with thorough research and conceptualization. I gather references, create mood boards, and sketch initial ideas to establish a clear vision."
    },
    {
      number: "02",
      title: "Modeling & Texturing",
      description: "I develop 3D models with precision and efficiency, focusing on topology and scale. Materials and textures are crafted to achieve the desired aesthetic and realism."
    },
    {
      number: "03",
      title: "Lighting & Rendering",
      description: "The scene comes to life through carefully placed lighting and camera work. I render high-quality outputs optimized for their intended purpose."
    }
  ];

  const clients = ["STUDIO ONE", "VISIUM", "ARTIFEX", "NEXUS"];

  return (
    <section id="process" className="py-20 px-6">
      <div className="max-w-6xl mx-auto text-center mb-16">
        <motion.span 
          className="text-blue-500 font-medium"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          My Process
        </motion.span>
        
        <motion.h2 
          className="text-4xl font-bold mt-2 mb-6"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          How I Bring Ideas to Life
        </motion.h2>
        
        <motion.p 
          className="text-gray-300 max-w-3xl mx-auto"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          My creative process is built on a foundation of research, planning, and iterative refinement. Each project follows a structured workflow that ensures quality results.
        </motion.p>
      </div>
      
      <div className="max-w-5xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {steps.map((step, index) => (
            <motion.div
              key={step.number}
              className="bg-gray-900 border border-gray-800 rounded-xl p-8 relative mt-10 md:mt-0"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ 
                duration: 0.5, 
                delay: index * 0.1 
              }}
              whileHover={{ y: -5 }}
            >
              <div className="absolute -top-5 -left-5 w-12 h-12 rounded-full bg-blue-500 flex items-center justify-center font-bold text-xl">
                {step.number}
              </div>
              <h3 className="text-xl font-semibold mt-4 mb-3">{step.title}</h3>
              <p className="text-gray-400">
                {step.description}
              </p>
            </motion.div>
          ))}
        </div>
        
        <motion.div 
          className="mt-20 text-center"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.3 }}
        >
          <h3 className="text-2xl font-bold mb-8">Featured Clients</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {clients.map((client, index) => (
              <motion.div
                key={client}
                className="flex items-center justify-center py-4 px-6 bg-gray-900/50 rounded-lg"
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ 
                  duration: 0.3, 
                  delay: index * 0.1 
                }}
                whileHover={{ 
                  scale: 1.05,
                  backgroundColor: "rgba(59, 130, 246, 0.1)" 
                }}
              >
                <span className="text-gray-400 font-medium">{client}</span>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
