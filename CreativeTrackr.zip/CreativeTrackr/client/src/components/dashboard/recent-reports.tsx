import { useQuery } from "@tanstack/react-query";
import { Report } from "@shared/schema";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Download, Eye, FileText } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";

interface RecentReportsProps {
  userId: number;
}

export default function RecentReports({ userId }: RecentReportsProps) {
  const { data: reports, isLoading } = useQuery({
    queryKey: ["/api/reports"],
    queryFn: async () => {
      // In a real application, we would fetch reports for all projects related to the user
      // For simplicity, we're using projectId 1 here
      const response = await fetch(`/api/reports?projectId=1`);
      if (!response.ok) {
        throw new Error("Failed to fetch reports");
      }
      return response.json() as Promise<Report[]>;
    }
  });

  if (isLoading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map((i) => (
          <Card key={i}>
            <CardHeader className="pb-2">
              <Skeleton className="h-6 w-3/4 mb-2" />
              <Skeleton className="h-4 w-1/2" />
            </CardHeader>
            <CardContent>
              <div className="flex justify-between items-center">
                <div>
                  <Skeleton className="h-4 w-32 mb-2" />
                  <Skeleton className="h-4 w-24" />
                </div>
                <Skeleton className="h-9 w-20 rounded-md" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (!reports || reports.length === 0) {
    return (
      <Card className="p-8 text-center">
        <CardTitle className="mb-2">No reports found</CardTitle>
        <CardDescription className="mb-4">
          Generate your first progress report to track and share project updates.
        </CardDescription>
        <Link href="/generate-report">
          <Button>Generate a Report</Button>
        </Link>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {reports.map((report) => (
        <Card key={report.id}>
          <CardHeader className="pb-2">
            <div className="flex justify-between items-start">
              <div>
                <CardTitle className="text-xl font-semibold">{report.title}</CardTitle>
                <CardDescription>
                  {new Date(report.startDate).toLocaleDateString()} - {new Date(report.endDate).toLocaleDateString()}
                </CardDescription>
              </div>
              {report.isPrivate && (
                <Badge variant="secondary">Private</Badge>
              )}
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex justify-between items-center">
              <div className="flex items-center space-x-4">
                <FileText className="h-5 w-5 text-primary" />
                <div>
                  <div className="text-sm font-medium">Project ID: {report.projectId}</div>
                  <div className="text-xs text-muted-foreground">
                    Created {new Date(report.createdAt).toLocaleDateString()}
                  </div>
                </div>
              </div>
              <div className="flex space-x-2">
                <Button variant="outline" size="sm">
                  <Eye className="h-4 w-4 mr-2" />
                  View
                </Button>
                <Button variant="outline" size="sm">
                  <Download className="h-4 w-4 mr-2" />
                  Export
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}