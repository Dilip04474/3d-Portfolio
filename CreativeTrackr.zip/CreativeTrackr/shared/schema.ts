import { pgTable, serial, text, timestamp, json, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull(),
  name: text("name").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

// Projects table
export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  userId: integer("user_id").references(() => users.id).notNull(),
  externalId: text("external_id"), // ID from external service
  externalSource: text("external_source"), // "trello", "asana", "jira", etc.
  accessToken: text("access_token"), // Encrypted token for API access
  settings: json("settings"), // JSON field for project-specific settings
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

// Tasks table
export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  status: text("status").notNull(), // "todo", "in_progress", "done"
  projectId: integer("project_id").references(() => projects.id).notNull(),
  externalId: text("external_id"),
  dueDate: timestamp("due_date"),
  completedAt: timestamp("completed_at"),
  assignee: text("assignee"),
  timeSpent: integer("time_spent"), // in minutes
  isPrivate: boolean("is_private").default(false).notNull(), // Privacy control
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

// Reports table
export const reports = pgTable("reports", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  projectId: integer("project_id").references(() => projects.id).notNull(),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  summary: text("summary"),
  content: json("content").notNull(), // Structured report data
  isPrivate: boolean("is_private").default(false).notNull(), // Privacy control
  createdAt: timestamp("created_at").defaultNow().notNull()
});

// Privacy settings table
export const privacySettings = pgTable("privacy_settings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  showTimeSpent: boolean("show_time_spent").default(true).notNull(),
  showAssigneeNames: boolean("show_assignee_names").default(true).notNull(),
  includeTaskDetails: boolean("include_task_details").default(true).notNull(),
  includePrivateTasks: boolean("include_private_tasks").default(false).notNull(),
  defaultReportPrivacy: boolean("default_report_privacy").default(false).notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

// API Connections table
export const apiConnections = pgTable("api_connections", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  serviceName: text("service_name").notNull(), // "trello", "asana", "jira", etc.
  accessToken: text("access_token"),
  refreshToken: text("refresh_token"),
  tokenExpiry: timestamp("token_expiry"),
  settings: json("settings"), // Service-specific settings
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  email: true,
  name: true
});

export const insertProjectSchema = createInsertSchema(projects).pick({
  name: true,
  description: true,
  userId: true,
  externalId: true,
  externalSource: true,
  accessToken: true,
  settings: true
});

export const insertTaskSchema = createInsertSchema(tasks).pick({
  name: true,
  description: true,
  status: true,
  projectId: true,
  externalId: true,
  dueDate: true,
  completedAt: true,
  assignee: true,
  timeSpent: true,
  isPrivate: true
});

export const insertReportSchema = createInsertSchema(reports).pick({
  title: true,
  projectId: true,
  startDate: true,
  endDate: true,
  summary: true,
  content: true,
  isPrivate: true
});

export const insertPrivacySettingsSchema = createInsertSchema(privacySettings).pick({
  userId: true,
  showTimeSpent: true,
  showAssigneeNames: true,
  includeTaskDetails: true,
  includePrivateTasks: true,
  defaultReportPrivacy: true
});

export const insertApiConnectionSchema = createInsertSchema(apiConnections).pick({
  userId: true,
  serviceName: true,
  accessToken: true,
  refreshToken: true,
  tokenExpiry: true,
  settings: true
});

// Export types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projects.$inferSelect;

export type InsertTask = z.infer<typeof insertTaskSchema>;
export type Task = typeof tasks.$inferSelect;

export type InsertReport = z.infer<typeof insertReportSchema>;
export type Report = typeof reports.$inferSelect;

export type InsertPrivacySettings = z.infer<typeof insertPrivacySettingsSchema>;
export type PrivacySettings = typeof privacySettings.$inferSelect;

export type InsertApiConnection = z.infer<typeof insertApiConnectionSchema>;
export type ApiConnection = typeof apiConnections.$inferSelect;