import { Express, Request, Response, NextFunction } from "express";
import { Server, createServer } from "http";
import { storage } from "./storage";
import { z } from "zod";
import {
  insertUserSchema,
  insertProjectSchema,
  insertTaskSchema,
  insertReportSchema,
  insertPrivacySettingsSchema,
  insertApiConnectionSchema
} from "@shared/schema";

// Middleware to handle async route handlers
const asyncHandler = 
  (fn: (req: Request, res: Response, next: NextFunction) => Promise<any>) => 
  (req: Request, res: Response, next: NextFunction) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };

export async function registerRoutes(app: Express): Promise<Server> {
  const server = createServer(app);
  // User routes
  app.get("/api/users/:id", asyncHandler(async (req, res) => {
    const userId = parseInt(req.params.id);
    const user = await storage.getUser(userId);
    
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    
    res.json(user);
  }));
  
  app.post("/api/users", asyncHandler(async (req, res) => {
    try {
      const validatedData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(validatedData);
      res.status(201).json(user);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      throw error;
    }
  }));
  
  // Project routes
  app.get("/api/projects", asyncHandler(async (req, res) => {
    const userId = req.query.userId ? parseInt(req.query.userId as string) : undefined;
    
    if (!userId) {
      return res.status(400).json({ error: "userId query parameter is required" });
    }
    
    const projects = await storage.getProjectsByUserId(userId);
    res.json(projects);
  }));
  
  app.get("/api/projects/:id", asyncHandler(async (req, res) => {
    const projectId = parseInt(req.params.id);
    const project = await storage.getProject(projectId);
    
    if (!project) {
      return res.status(404).json({ error: "Project not found" });
    }
    
    res.json(project);
  }));
  
  app.post("/api/projects", asyncHandler(async (req, res) => {
    try {
      const validatedData = insertProjectSchema.parse(req.body);
      const project = await storage.createProject(validatedData);
      res.status(201).json(project);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      throw error;
    }
  }));
  
  app.patch("/api/projects/:id", asyncHandler(async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const updateData = insertProjectSchema.partial().parse(req.body);
      const project = await storage.updateProject(projectId, updateData);
      res.json(project);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      throw error;
    }
  }));
  
  app.delete("/api/projects/:id", asyncHandler(async (req, res) => {
    const projectId = parseInt(req.params.id);
    const success = await storage.deleteProject(projectId);
    
    if (!success) {
      return res.status(404).json({ error: "Project not found" });
    }
    
    res.status(204).end();
  }));
  
  // Task routes
  app.get("/api/tasks", asyncHandler(async (req, res) => {
    const projectId = req.query.projectId ? parseInt(req.query.projectId as string) : undefined;
    const includePrivate = req.query.includePrivate === "true";
    
    if (!projectId) {
      return res.status(400).json({ error: "projectId query parameter is required" });
    }
    
    const tasks = await storage.getTasksByProjectId(projectId, includePrivate);
    res.json(tasks);
  }));
  
  app.get("/api/tasks/:id", asyncHandler(async (req, res) => {
    const taskId = parseInt(req.params.id);
    const task = await storage.getTask(taskId);
    
    if (!task) {
      return res.status(404).json({ error: "Task not found" });
    }
    
    res.json(task);
  }));
  
  app.post("/api/tasks", asyncHandler(async (req, res) => {
    try {
      const validatedData = insertTaskSchema.parse(req.body);
      const task = await storage.createTask(validatedData);
      res.status(201).json(task);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      throw error;
    }
  }));
  
  app.patch("/api/tasks/:id", asyncHandler(async (req, res) => {
    try {
      const taskId = parseInt(req.params.id);
      const updateData = insertTaskSchema.partial().parse(req.body);
      const task = await storage.updateTask(taskId, updateData);
      res.json(task);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      throw error;
    }
  }));
  
  app.delete("/api/tasks/:id", asyncHandler(async (req, res) => {
    const taskId = parseInt(req.params.id);
    const success = await storage.deleteTask(taskId);
    
    if (!success) {
      return res.status(404).json({ error: "Task not found" });
    }
    
    res.status(204).end();
  }));
  
  // Report routes
  app.get("/api/reports", asyncHandler(async (req, res) => {
    const projectId = req.query.projectId ? parseInt(req.query.projectId as string) : undefined;
    
    if (!projectId) {
      return res.status(400).json({ error: "projectId query parameter is required" });
    }
    
    const reports = await storage.getReportsByProjectId(projectId);
    res.json(reports);
  }));
  
  app.get("/api/reports/:id", asyncHandler(async (req, res) => {
    const reportId = parseInt(req.params.id);
    const report = await storage.getReport(reportId);
    
    if (!report) {
      return res.status(404).json({ error: "Report not found" });
    }
    
    res.json(report);
  }));
  
  app.post("/api/reports", asyncHandler(async (req, res) => {
    try {
      const validatedData = insertReportSchema.parse(req.body);
      const report = await storage.createReport(validatedData);
      res.status(201).json(report);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      throw error;
    }
  }));
  
  app.patch("/api/reports/:id", asyncHandler(async (req, res) => {
    try {
      const reportId = parseInt(req.params.id);
      const updateData = insertReportSchema.partial().parse(req.body);
      const report = await storage.updateReport(reportId, updateData);
      res.json(report);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      throw error;
    }
  }));
  
  app.delete("/api/reports/:id", asyncHandler(async (req, res) => {
    const reportId = parseInt(req.params.id);
    const success = await storage.deleteReport(reportId);
    
    if (!success) {
      return res.status(404).json({ error: "Report not found" });
    }
    
    res.status(204).end();
  }));
  
  // Generate report endpoint
  app.post("/api/projects/:id/generate-report", asyncHandler(async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const project = await storage.getProject(projectId);
      
      if (!project) {
        return res.status(404).json({ error: "Project not found" });
      }
      
      const { startDate: startDateStr, endDate: endDateStr, title, isPrivate = false } = req.body;
      
      if (!startDateStr || !endDateStr || !title) {
        return res.status(400).json({ error: "startDate, endDate, and title are required" });
      }
      
      const startDate = new Date(startDateStr);
      const endDate = new Date(endDateStr);
      
      // Get tasks relevant to the report period
      const tasks = await storage.getTasksByProjectId(projectId, true);
      
      // Get privacy settings for the user
      const privacySettings = await storage.getPrivacySettings(project.userId);
      
      // Filter tasks based on privacy settings and date range
      const filteredTasks = tasks.filter(task => {
        // Only include tasks that match the date range
        const taskInRange = (!task.completedAt || (task.completedAt >= startDate && task.completedAt <= endDate));
        
        // Apply privacy filters
        const includePrivateTask = privacySettings?.includePrivateTasks || !task.isPrivate;
        
        return taskInRange && includePrivateTask;
      });
      
      // Calculate statistics
      const completedTasks = filteredTasks.filter(task => task.status === "done").length;
      const inProgressTasks = filteredTasks.filter(task => task.status === "in_progress").length;
      const pendingTasks = filteredTasks.filter(task => task.status === "todo").length;
      
      // Calculate task breakdown by status
      const taskBreakdown = [
        { status: "done", count: completedTasks },
        { status: "in_progress", count: inProgressTasks },
        { status: "todo", count: pendingTasks }
      ];
      
      // Calculate total time spent
      const totalTimeSpent = filteredTasks.reduce((total, task) => total + (task.timeSpent || 0), 0);
      
      // Calculate top contributors
      const contributorsMap = new Map();
      
      filteredTasks.forEach(task => {
        if (task.assignee && (privacySettings?.showAssigneeNames || true)) {
          const timeSpent = privacySettings?.showTimeSpent ? (task.timeSpent || 0) : 0;
          
          if (contributorsMap.has(task.assignee)) {
            const contributor = contributorsMap.get(task.assignee);
            contributor.tasks += 1;
            contributor.timeSpent += timeSpent;
          } else {
            contributorsMap.set(task.assignee, {
              name: task.assignee,
              tasks: 1,
              timeSpent
            });
          }
        }
      });
      
      const topContributors = Array.from(contributorsMap.values())
        .sort((a, b) => b.timeSpent - a.timeSpent || b.tasks - a.tasks)
        .slice(0, 5);
      
      // Create the report
      const report = {
        title,
        projectId,
        startDate,
        endDate,
        summary: `Report for ${project.name} from ${startDate.toLocaleDateString()} to ${endDate.toLocaleDateString()}`,
        content: {
          completedTasks,
          inProgressTasks,
          pendingTasks,
          taskBreakdown,
          totalTimeSpent,
          topContributors,
          tasks: privacySettings?.includeTaskDetails ? filteredTasks : undefined
        },
        isPrivate: isPrivate || (privacySettings?.defaultReportPrivacy || false)
      };
      
      const savedReport = await storage.createReport(report);
      res.status(201).json(savedReport);
    } catch (error) {
      console.error("Error generating report:", error);
      throw error;
    }
  }));
  
  // Privacy settings routes
  app.get("/api/privacy-settings", asyncHandler(async (req, res) => {
    const userId = req.query.userId ? parseInt(req.query.userId as string) : undefined;
    
    if (!userId) {
      return res.status(400).json({ error: "userId query parameter is required" });
    }
    
    const settings = await storage.getPrivacySettings(userId);
    
    if (!settings) {
      return res.status(404).json({ error: "Privacy settings not found" });
    }
    
    res.json(settings);
  }));
  
  app.post("/api/privacy-settings", asyncHandler(async (req, res) => {
    try {
      const validatedData = insertPrivacySettingsSchema.parse(req.body);
      const settings = await storage.createOrUpdatePrivacySettings(validatedData);
      res.status(201).json(settings);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      throw error;
    }
  }));
  
  // API Connection routes
  app.get("/api/api-connections", asyncHandler(async (req, res) => {
    const userId = req.query.userId ? parseInt(req.query.userId as string) : undefined;
    
    if (!userId) {
      return res.status(400).json({ error: "userId query parameter is required" });
    }
    
    const connections = await storage.getApiConnectionsByUserId(userId);
    res.json(connections);
  }));
  
  app.get("/api/api-connections/:id", asyncHandler(async (req, res) => {
    const connectionId = parseInt(req.params.id);
    const connection = await storage.getApiConnection(connectionId);
    
    if (!connection) {
      return res.status(404).json({ error: "API Connection not found" });
    }
    
    res.json(connection);
  }));
  
  app.post("/api/api-connections", asyncHandler(async (req, res) => {
    try {
      const validatedData = insertApiConnectionSchema.parse(req.body);
      const connection = await storage.createApiConnection(validatedData);
      res.status(201).json(connection);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      throw error;
    }
  }));
  
  app.patch("/api/api-connections/:id", asyncHandler(async (req, res) => {
    try {
      const connectionId = parseInt(req.params.id);
      const updateData = insertApiConnectionSchema.partial().parse(req.body);
      const connection = await storage.updateApiConnection(connectionId, updateData);
      res.json(connection);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      throw error;
    }
  }));
  
  app.delete("/api/api-connections/:id", asyncHandler(async (req, res) => {
    const connectionId = parseInt(req.params.id);
    const success = await storage.deleteApiConnection(connectionId);
    
    if (!success) {
      return res.status(404).json({ error: "API Connection not found" });
    }
    
    res.status(204).end();
  }));
  
  // Endpoint to fetch supported integrations
  app.get("/api/integrations", (req, res) => {
    const integrations = [
      {
        id: "trello",
        name: "Trello",
        description: "Connect to your Trello boards to import tasks and generate reports.",
        icon: "trello"
      },
      {
        id: "asana",
        name: "Asana",
        description: "Connect to your Asana projects to import tasks and generate reports.",
        icon: "asana"
      },
      {
        id: "jira",
        name: "Jira",
        description: "Connect to your Jira projects to import issues and generate reports.",
        icon: "jira"
      },
      {
        id: "github",
        name: "GitHub",
        description: "Connect to your GitHub repositories to import issues and generate reports.",
        icon: "github"
      },
      {
        id: "monday",
        name: "Monday.com",
        description: "Connect to your Monday.com boards to import items and generate reports.",
        icon: "monday"
      }
    ];
    
    res.json(integrations);
  });
  
  return Promise.resolve(server);
}