import {
  User, InsertUser,
  Project, InsertProject,
  Task, InsertTask,
  Report, InsertReport,
  PrivacySettings, InsertPrivacySettings,
  ApiConnection, InsertApiConnection
} from "@shared/schema";

// Storage interface for the application
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Project operations
  getProject(id: number): Promise<Project | undefined>;
  getProjectsByUserId(userId: number): Promise<Project[]>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: number, project: Partial<InsertProject>): Promise<Project>;
  deleteProject(id: number): Promise<boolean>;
  
  // Task operations
  getTask(id: number): Promise<Task | undefined>;
  getTasksByProjectId(projectId: number, includePrivate?: boolean): Promise<Task[]>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: number, task: Partial<InsertTask>): Promise<Task>;
  deleteTask(id: number): Promise<boolean>;
  
  // Report operations
  getReport(id: number): Promise<Report | undefined>;
  getReportsByProjectId(projectId: number): Promise<Report[]>;
  createReport(report: InsertReport): Promise<Report>;
  updateReport(id: number, report: Partial<InsertReport>): Promise<Report>;
  deleteReport(id: number): Promise<boolean>;
  
  // Privacy settings operations
  getPrivacySettings(userId: number): Promise<PrivacySettings | undefined>;
  createOrUpdatePrivacySettings(settings: InsertPrivacySettings): Promise<PrivacySettings>;
  
  // API Connection operations
  getApiConnection(id: number): Promise<ApiConnection | undefined>;
  getApiConnectionsByUserId(userId: number): Promise<ApiConnection[]>;
  getApiConnectionByService(userId: number, serviceName: string): Promise<ApiConnection | undefined>;
  createApiConnection(connection: InsertApiConnection): Promise<ApiConnection>;
  updateApiConnection(id: number, connection: Partial<InsertApiConnection>): Promise<ApiConnection>;
  deleteApiConnection(id: number): Promise<boolean>;
}

// In-memory implementation of the storage interface
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private projects: Map<number, Project>;
  private tasks: Map<number, Task>;
  private reports: Map<number, Report>;
  private privacySettings: Map<number, PrivacySettings>; // Key is userId
  private apiConnections: Map<number, ApiConnection>;
  
  private currentUserId: number;
  private currentProjectId: number;
  private currentTaskId: number;
  private currentReportId: number;
  private currentPrivacySettingsId: number;
  private currentApiConnectionId: number;
  
  constructor() {
    this.users = new Map();
    this.projects = new Map();
    this.tasks = new Map();
    this.reports = new Map();
    this.privacySettings = new Map();
    this.apiConnections = new Map();
    
    this.currentUserId = 1;
    this.currentProjectId = 1;
    this.currentTaskId = 1;
    this.currentReportId = 1;
    this.currentPrivacySettingsId = 1;
    this.currentApiConnectionId = 1;
    
    // Add demo data
    this.initializeDemoData();
  }
  
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }
  
  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const now = new Date();
    const user: User = { ...insertUser, id, createdAt: now };
    this.users.set(id, user);
    return user;
  }
  
  // Project operations
  async getProject(id: number): Promise<Project | undefined> {
    return this.projects.get(id);
  }
  
  async getProjectsByUserId(userId: number): Promise<Project[]> {
    return Array.from(this.projects.values()).filter(
      (project) => project.userId === userId
    );
  }
  
  async createProject(project: InsertProject): Promise<Project> {
    const id = this.currentProjectId++;
    const now = new Date();
    const newProject: Project = {
      ...project,
      id,
      description: project.description || null,
      externalId: project.externalId || null,
      externalSource: project.externalSource || null,
      accessToken: project.accessToken || null,
      settings: project.settings || {},
      createdAt: now,
      updatedAt: now
    };
    this.projects.set(id, newProject);
    return newProject;
  }
  
  async updateProject(id: number, project: Partial<InsertProject>): Promise<Project> {
    const existingProject = await this.getProject(id);
    if (!existingProject) {
      throw new Error(`Project with id ${id} not found`);
    }
    
    const updatedProject: Project = {
      ...existingProject,
      ...project,
      updatedAt: new Date()
    };
    
    this.projects.set(id, updatedProject);
    return updatedProject;
  }
  
  async deleteProject(id: number): Promise<boolean> {
    return this.projects.delete(id);
  }
  
  // Task operations
  async getTask(id: number): Promise<Task | undefined> {
    return this.tasks.get(id);
  }
  
  async getTasksByProjectId(projectId: number, includePrivate: boolean = false): Promise<Task[]> {
    return Array.from(this.tasks.values()).filter(
      (task) => task.projectId === projectId && (includePrivate || !task.isPrivate)
    );
  }
  
  async createTask(task: InsertTask): Promise<Task> {
    const id = this.currentTaskId++;
    const now = new Date();
    const newTask: Task = {
      ...task,
      id,
      description: task.description || null,
      externalId: task.externalId || null,
      dueDate: task.dueDate || null,
      completedAt: task.completedAt || null,
      assignee: task.assignee || null,
      timeSpent: task.timeSpent || null,
      isPrivate: task.isPrivate === undefined ? false : task.isPrivate,
      createdAt: now,
      updatedAt: now
    };
    this.tasks.set(id, newTask);
    return newTask;
  }
  
  async updateTask(id: number, task: Partial<InsertTask>): Promise<Task> {
    const existingTask = await this.getTask(id);
    if (!existingTask) {
      throw new Error(`Task with id ${id} not found`);
    }
    
    const updatedTask: Task = {
      ...existingTask,
      ...task,
      updatedAt: new Date()
    };
    
    this.tasks.set(id, updatedTask);
    return updatedTask;
  }
  
  async deleteTask(id: number): Promise<boolean> {
    return this.tasks.delete(id);
  }
  
  // Report operations
  async getReport(id: number): Promise<Report | undefined> {
    return this.reports.get(id);
  }
  
  async getReportsByProjectId(projectId: number): Promise<Report[]> {
    return Array.from(this.reports.values()).filter(
      (report) => report.projectId === projectId
    );
  }
  
  async createReport(report: InsertReport): Promise<Report> {
    const id = this.currentReportId++;
    const now = new Date();
    const newReport: Report = {
      ...report,
      id,
      summary: report.summary || null,
      isPrivate: report.isPrivate === undefined ? false : report.isPrivate,
      createdAt: now
    };
    this.reports.set(id, newReport);
    return newReport;
  }
  
  async updateReport(id: number, report: Partial<InsertReport>): Promise<Report> {
    const existingReport = await this.getReport(id);
    if (!existingReport) {
      throw new Error(`Report with id ${id} not found`);
    }
    
    const updatedReport: Report = {
      ...existingReport,
      ...report
    };
    
    this.reports.set(id, updatedReport);
    return updatedReport;
  }
  
  async deleteReport(id: number): Promise<boolean> {
    return this.reports.delete(id);
  }
  
  // Privacy settings operations
  async getPrivacySettings(userId: number): Promise<PrivacySettings | undefined> {
    return Array.from(this.privacySettings.values()).find(
      (settings) => settings.userId === userId
    );
  }
  
  async createOrUpdatePrivacySettings(settings: InsertPrivacySettings): Promise<PrivacySettings> {
    const existingSettings = await this.getPrivacySettings(settings.userId);
    
    if (existingSettings) {
      const updatedSettings: PrivacySettings = {
        ...existingSettings,
        userId: settings.userId,
        showTimeSpent: settings.showTimeSpent === undefined ? existingSettings.showTimeSpent : settings.showTimeSpent,
        showAssigneeNames: settings.showAssigneeNames === undefined ? existingSettings.showAssigneeNames : settings.showAssigneeNames,
        includeTaskDetails: settings.includeTaskDetails === undefined ? existingSettings.includeTaskDetails : settings.includeTaskDetails,
        includePrivateTasks: settings.includePrivateTasks === undefined ? existingSettings.includePrivateTasks : settings.includePrivateTasks,
        defaultReportPrivacy: settings.defaultReportPrivacy === undefined ? existingSettings.defaultReportPrivacy : settings.defaultReportPrivacy,
        updatedAt: new Date()
      };
      
      this.privacySettings.set(existingSettings.id, updatedSettings);
      return updatedSettings;
    } else {
      const id = this.currentPrivacySettingsId++;
      const now = new Date();
      const newSettings: PrivacySettings = {
        id,
        userId: settings.userId,
        showTimeSpent: settings.showTimeSpent === undefined ? true : settings.showTimeSpent,
        showAssigneeNames: settings.showAssigneeNames === undefined ? true : settings.showAssigneeNames,
        includeTaskDetails: settings.includeTaskDetails === undefined ? true : settings.includeTaskDetails,
        includePrivateTasks: settings.includePrivateTasks === undefined ? false : settings.includePrivateTasks,
        defaultReportPrivacy: settings.defaultReportPrivacy === undefined ? false : settings.defaultReportPrivacy,
        updatedAt: now
      };
      
      this.privacySettings.set(id, newSettings);
      return newSettings;
    }
  }
  
  // API Connection operations
  async getApiConnection(id: number): Promise<ApiConnection | undefined> {
    return this.apiConnections.get(id);
  }
  
  async getApiConnectionsByUserId(userId: number): Promise<ApiConnection[]> {
    return Array.from(this.apiConnections.values()).filter(
      (connection) => connection.userId === userId
    );
  }
  
  async getApiConnectionByService(userId: number, serviceName: string): Promise<ApiConnection | undefined> {
    return Array.from(this.apiConnections.values()).find(
      (connection) => connection.userId === userId && connection.serviceName === serviceName
    );
  }
  
  async createApiConnection(connection: InsertApiConnection): Promise<ApiConnection> {
    const id = this.currentApiConnectionId++;
    const now = new Date();
    const newConnection: ApiConnection = {
      id,
      userId: connection.userId,
      serviceName: connection.serviceName,
      accessToken: connection.accessToken || null,
      refreshToken: connection.refreshToken || null,
      tokenExpiry: connection.tokenExpiry || null,
      settings: connection.settings || {},
      createdAt: now,
      updatedAt: now
    };
    this.apiConnections.set(id, newConnection);
    return newConnection;
  }
  
  async updateApiConnection(id: number, connection: Partial<InsertApiConnection>): Promise<ApiConnection> {
    const existingConnection = await this.getApiConnection(id);
    if (!existingConnection) {
      throw new Error(`API Connection with id ${id} not found`);
    }
    
    const updatedConnection: ApiConnection = {
      ...existingConnection,
      ...connection,
      updatedAt: new Date()
    };
    
    this.apiConnections.set(id, updatedConnection);
    return updatedConnection;
  }
  
  async deleteApiConnection(id: number): Promise<boolean> {
    return this.apiConnections.delete(id);
  }
  
  // Initialize demo data
  private initializeDemoData() {
    // Create a demo user
    const demoUser: InsertUser = {
      username: "demo",
      email: "demo@example.com",
      name: "Demo User"
    };
    
    this.createUser(demoUser).then(user => {
      // Create privacy settings for the user
      const privacySettings: InsertPrivacySettings = {
        userId: user.id,
        showTimeSpent: true,
        showAssigneeNames: true,
        includeTaskDetails: true,
        includePrivateTasks: false,
        defaultReportPrivacy: false
      };
      
      this.createOrUpdatePrivacySettings(privacySettings);
      
      // Create sample API connections
      const trelloConnection: InsertApiConnection = {
        userId: user.id,
        serviceName: "trello",
        accessToken: null,
        refreshToken: null,
        tokenExpiry: null,
        settings: {}
      };
      
      const asanaConnection: InsertApiConnection = {
        userId: user.id,
        serviceName: "asana",
        accessToken: null,
        refreshToken: null,
        tokenExpiry: null,
        settings: {}
      };
      
      this.createApiConnection(trelloConnection);
      this.createApiConnection(asanaConnection);
      
      // Create a sample project
      const project: InsertProject = {
        name: "Website Redesign",
        description: "Complete overhaul of the company website",
        userId: user.id,
        externalId: null,
        externalSource: null,
        accessToken: null,
        settings: {}
      };
      
      this.createProject(project).then(project => {
        // Create sample tasks
        const tasks: InsertTask[] = [
          {
            name: "Design homepage mockup",
            description: "Create wireframes and visual design for the new homepage",
            status: "done",
            projectId: project.id,
            externalId: null,
            dueDate: new Date("2025-05-01"),
            completedAt: new Date("2025-04-28"),
            assignee: "Sarah Chen",
            timeSpent: 480, // 8 hours
            isPrivate: false
          },
          {
            name: "Develop responsive layout",
            description: "Implement responsive grid system for all screen sizes",
            status: "in_progress",
            projectId: project.id,
            externalId: null,
            dueDate: new Date("2025-05-10"),
            completedAt: null,
            assignee: "Michael Johnson",
            timeSpent: 360, // 6 hours
            isPrivate: false
          },
          {
            name: "Content migration",
            description: "Transfer all existing content to the new CMS",
            status: "todo",
            projectId: project.id,
            externalId: null,
            dueDate: new Date("2025-05-15"),
            completedAt: null,
            assignee: "Jessica Smith",
            timeSpent: 0,
            isPrivate: false
          },
          {
            name: "Backend integration",
            description: "Connect frontend to API endpoints",
            status: "todo",
            projectId: project.id,
            externalId: null,
            dueDate: new Date("2025-05-20"),
            completedAt: null,
            assignee: "David Williams",
            timeSpent: 0,
            isPrivate: true // Private task
          }
        ];
        
        Promise.all(tasks.map(task => this.createTask(task))).then(_ => {
          // Create a sample report
          const oneWeekAgo = new Date();
          oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
          
          const report: InsertReport = {
            title: "Weekly Progress - Website Redesign",
            projectId: project.id,
            startDate: oneWeekAgo,
            endDate: new Date(),
            summary: "Good progress on design phase. Development started. Some delays in content preparation.",
            content: {
              completedTasks: 1,
              inProgressTasks: 1,
              pendingTasks: 2,
              taskBreakdown: [
                { status: "done", count: 1 },
                { status: "in_progress", count: 1 },
                { status: "todo", count: 2 }
              ],
              totalTimeSpent: 840, // 14 hours
              topContributors: [
                { name: "Sarah Chen", tasks: 1, timeSpent: 480 },
                { name: "Michael Johnson", tasks: 1, timeSpent: 360 }
              ],
              milestoneStatus: {
                design: "completed",
                development: "in-progress",
                contentMigration: "not-started",
                testing: "not-started",
                deployment: "not-started"
              }
            },
            isPrivate: false
          };
          
          this.createReport(report);
        });
      });
    });
  }
}

// Export a single instance of MemStorage
export const storage = new MemStorage();